import os
import subprocess
import platform
from colorama import Fore

def install_python_modules():
    try:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'dnspython', 'tinydb', 'colorama', 'pymongo', 'flask'])
    except subprocess.CalledProcessError:
        print(Fore.RED + 'Error installing modules')

def install_application(apps_dir, program_name):
    app_path = os.path.join(apps_dir, program_name)
    os.makedirs(app_path, exist_ok=True)
    with open(os.path.join(app_path, f'{program_name}.rkp'), 'w') as f:
        f.write(f'{program_name} installed successfully.')

def update_system_drivers():
    if platform.system() == 'Windows':
        subprocess.call(['powershell', 'Update-Drivers'])  # Placeholder for driver update command
    else:
        subprocess.call(['sudo', 'apt-get', 'update'])  # Placeholder for driver update command

def lock_python_executable():
    if platform.system() == 'Windows':
        subprocess.call(['attrib', '+h', sys.executable])  # Hide Python executable
    else:
        os.chmod(sys.executable, 0o000)  # Remove all permissions

def get_wifi_status():
    if platform.system() == 'Windows':
        output = subprocess.check_output(['powershell', 'Get-NetConnectionProfile'])
        return output.decode()
    else:
        output = subprocess.check_output(['iwgetid'])
        return output.decode()

def run_program(program_name):
    app_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'applications', program_name)
    program_file = os.path.join(app_path, f'{program_name}.rkp')
    if os.path.exists(program_file):
        print(Fore.GREEN + f'Running {program_name}...')
        subprocess.call([sys.executable, program_file])
    else:
        print(Fore.RED + f'{program_name} is not installed.')