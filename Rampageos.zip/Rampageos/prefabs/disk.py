import pygame
import subprocess
import os

pygame.init()

SCREEN_WIDTH = pygame.display.Info().current_w
SCREEN_HEIGHT = pygame.display.Info().current_h
TASKBAR_HEIGHT = 60

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.FULLSCREEN)
pygame.display.set_caption('RampageOS System')

desktop_theme = pygame.image.load('Icons/DesktopTheme.png')
start_menu_icon = pygame.image.load('Icons/Tsk.png')
firefox_icon = pygame.image.load('Icons/Firefox.png')
terminal_icon = pygame.image.load('Icons/Terminal.png')
anbox_icon = pygame.image.load('Icons/Anbox.png')

font = pygame.font.SysFont('Arial', 24)
small_font = pygame.font.SysFont('Arial', 18)

def draw_text(text, font, color, surface, x, y):
    text_obj = font.render(text, True, color)
    text_rect = text_obj.get_rect()
    text_rect.topleft = (x, y)
    surface.blit(text_obj, text_rect)

def draw_icon(icon, x, y, width, height):
    if icon:
        icon = pygame.transform.scale(icon, (width, height))
        screen.blit(icon, (x, y))

def open_terminal():
    try:
        subprocess.Popen(['xterm'])
    except FileNotFoundError:
        print("xterm is not installed.")

def open_anbox():
    try:
        subprocess.Popen(['anbox', 'app-manager'])
    except FileNotFoundError:
        print("Anbox is not installed or not configured correctly.")

def show_context_menu():
    menu_items = ['Open', 'Refresh', 'Properties']
    context_menu_surface = pygame.Surface((200, len(menu_items) * 40))
    context_menu_surface.set_alpha(200)  # Set transparency
    context_menu_surface.fill((50, 50, 50))

    for i, item in enumerate(menu_items):
        draw_text(item, small_font, (255, 255, 255), context_menu_surface, 10, i * 40 + 10)

    screen.blit(context_menu_surface, (pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1]))
    pygame.display.update()

running = True
show_menu = False

while running:
    screen.blit(pygame.transform.scale(desktop_theme, (SCREEN_WIDTH, SCREEN_HEIGHT)), (0, 0))

    pygame.draw.rect(screen, (0, 0, 0, 150), (0, SCREEN_HEIGHT - TASKBAR_HEIGHT, SCREEN_WIDTH, TASKBAR_HEIGHT))  # Transparent taskbar

    draw_icon(start_menu_icon, 20, SCREEN_HEIGHT - TASKBAR_HEIGHT + 8, 64, 64)
    draw_icon(firefox_icon, 100, SCREEN_HEIGHT - TASKBAR_HEIGHT + 8, 64, 64)
    draw_icon(terminal_icon, 180, SCREEN_HEIGHT - TASKBAR_HEIGHT + 8, 64, 64)
    draw_icon(anbox_icon, 260, SCREEN_HEIGHT - TASKBAR_HEIGHT + 8, 64, 64)

    draw_text('Start Menu', small_font, (255, 255, 255), screen, 20, SCREEN_HEIGHT - TASKBAR_HEIGHT + 80)
    draw_text('Firefox', small_font, (255, 255, 255), screen, 100, SCREEN_HEIGHT - TASKBAR_HEIGHT + 80)
    draw_text('Terminal', small_font, (255, 255, 255), screen, 180, SCREEN_HEIGHT - TASKBAR_HEIGHT + 80)
    draw_text('Anbox', small_font, (255, 255, 255), screen, 260, SCREEN_HEIGHT - TASKBAR_HEIGHT + 80)

    if show_menu:
        show_context_menu()

    pygame.display.update()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = event.pos
            if event.button == 3:  # Right mouse button
                if mouse_y < SCREEN_HEIGHT - TASKBAR_HEIGHT:  # Click on desktop
                    show_menu = True
            elif 20 <= mouse_x <= 84 and SCREEN_HEIGHT - TASKBAR_HEIGHT + 8 <= mouse_y <= SCREEN_HEIGHT - TASKBAR_HEIGHT + 72:
                pass
            elif 100 <= mouse_x <= 164 and SCREEN_HEIGHT - TASKBAR_HEIGHT + 8 <= mouse_y <= SCREEN_HEIGHT - TASKBAR_HEIGHT + 72:
                pass
            elif 180 <= mouse_x <= 244 and SCREEN_HEIGHT - TASKBAR_HEIGHT + 8 <= mouse_y <= SCREEN_HEIGHT - TASKBAR_HEIGHT + 72:
                open_terminal()
            elif 260 <= mouse_x <= 324 and SCREEN_HEIGHT - TASKBAR_HEIGHT + 8 <= mouse_y <= SCREEN_HEIGHT - TASKBAR_HEIGHT + 72:
                open_anbox()

pygame.quit()