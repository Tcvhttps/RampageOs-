import os
from datetime import datetime

class VirtualMemory:
    def __init__(self, memory_size_in_mb=1024):
        self.memory_size_in_mb = memory_size_in_mb
        self.memory_file = 'virtual_memory.bin'
        self.create_virtual_memory()

    def create_virtual_memory(self):
        """Створити віртуальну пам'ять."""
        if not os.path.exists(self.memory_file):
            print(f"Creating virtual memory of size {self.memory_size_in_mb}MB...")
            with open(self.memory_file, 'wb') as memory:
                memory.write(b'\x00' * (self.memory_size_in_mb * 1024 * 1024))
            print("Virtual memory created.")
        else:
            print("Virtual memory already exists.")

    def log_memory_action(self, action):
        """Записати дію користувача у віртуальну пам'ять."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] {action} logged in memory.\n"
        
        with open(self.memory_file, 'ab') as memory_log:
            memory_log.write(log_entry.encode())

        print(f"Memory module: Action '{action}' logged.")

    def delete_virtual_memory(self):
        """Видалити віртуальну пам'ять."""
        if os.path.exists(self.memory_file):
            os.remove(self.memory_file)
            print("Virtual memory deleted.")
        else:
            print("Virtual memory does not exist.")


# Функція для використання в головному коді
virtual_memory = VirtualMemory()

def log_memory_action(action):
    virtual_memory.log_memory_action(action)