import os
import time
from datetime import datetime

class VirtualDisk:
    def __init__(self, disk_path, virtual_disk_path='virtual_disk.bin'):
        self.disk_path = disk_path
        self.virtual_disk_path = virtual_disk_path
        self.total_size = self.get_total_disk_size()
        self.create_virtual_disk()

    def get_total_disk_size(self):
        """Отримати загальний розмір диска."""
        statvfs = os.statvfs(self.disk_path)
        total_size = statvfs.f_frsize * statvfs.f_blocks  # Загальний розмір диска
        return total_size

    def create_virtual_disk(self):
        """Створити віртуальний диск розміром з фізичний диск."""
        if not os.path.exists(self.virtual_disk_path):
            print(f"Creating virtual disk of size {self.total_size / (1024 * 1024 * 1024):.2f} GB...")
            with open(self.virtual_disk_path, 'wb') as virtual_disk:
                virtual_disk.write(b'\x00' * self.total_size)  # Записуємо нулі, щоб створити віртуальний диск
            print("Virtual disk created.")
        else:
            print("Virtual disk already exists.")

    def log_action(self, action):
        """Записати дію користувача у віртуальний диск."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] {action}\n"
        with open(self.virtual_disk_path, 'ab') as virtual_disk:
            virtual_disk.write(log_entry.encode())
        print(f"Action '{action}' logged on the virtual disk.")

    def delete_virtual_disk(self):
        """Видалити віртуальний диск."""
        if os.path.exists(self.virtual_disk_path):
            os.remove(self.virtual_disk_path)
            print("Virtual disk deleted.")
        else:
            print("Virtual disk does not exist.")

# Приклад використання
if __name__ == "__main__":
    # Замініть '/' на 'C:' для Windows або інший диск для Unix-подібних ОС
    virtual_disk = VirtualDisk(disk_path='/')

    while True:
        user_input = input("Enter a command or 'exit' to quit: ")
        if user_input.lower() == 'exit':
            virtual_disk.log_action('User exited the system.')
            virtual_disk.delete_virtual_disk()
            break
        else:
            virtual_disk.log_action(f'User performed action: {user_input}')
            print("Action logged.")