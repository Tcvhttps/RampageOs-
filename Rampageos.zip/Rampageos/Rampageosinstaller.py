import pygame
import os
import time

pygame.init()

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
TASKBAR_HEIGHT = 60
SESSION_FILE = 'prefabs/Session.rkp'

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('RampageOS Installer')

logo = pygame.image.load('prefabs/SystemImages/logo.png')
pygame.display.set_icon(logo)

black = (0, 0, 0)
white = (255, 255, 255)
red = (255, 0, 0)
blue = (0, 0, 255)

font = pygame.font.SysFont(None, 48)
small_font = pygame.font.SysFont(None, 36)

languages = ['English', 'Русский', 'Українська']
language_selected = 0
installing = False
progress = 0

def draw_text(text, font, color, surface, x, y):
    text_obj = font.render(text, True, color)
    text_rect = text_obj.get_rect()
    text_rect.topleft = (x, y)
    surface.blit(text_obj, text_rect)

# Check if the system is already installed
if os.path.exists(SESSION_FILE):
    pygame.quit()
    os.system('python3 prefabs/disk.py')
    exit()

running = True
while running:
    screen.fill(black)
    
    if not installing:
        draw_text('RampageOS Installer', font, white, screen, 20, 20)
        draw_text('Select language:', small_font, white, screen, 20, 100)

        for i, lang in enumerate(languages):
            color = blue if i == language_selected else white
            draw_text(f'{i+1}. {lang}', small_font, color, screen, 40, 150 + i * 40)

        draw_text('Press ENTER to install', small_font, white, screen, 20, 400)

        keys = pygame.key.get_pressed()

        if keys[pygame.K_UP]:
            language_selected = (language_selected - 1) % len(languages)
            time.sleep(0.2)

        if keys[pygame.K_DOWN]:
            language_selected = (language_selected + 1) % len(languages)
            time.sleep(0.2)

        if keys[pygame.K_RETURN]:
            installing = True
            progress = 0
            time.sleep(0.5)

    else:
        if progress < 100:
            pygame.draw.rect(screen, white, pygame.Rect(20, 100, 760, 40))
            pygame.draw.rect(screen, red, pygame.Rect(20, 100, 7.6 * progress, 40))
            log_message = f'Installing... {progress}%'
            progress += 1
            time.sleep(0.3)
        else:
            log_message = 'Installation Complete! Launching system...'
            pygame.draw.rect(screen, black, pygame.Rect(20, 160, 760, 400))
            draw_text(log_message, small_font, white, screen, 20, 160)
            
            # Create the session file
            with open(SESSION_FILE, 'w') as f:
                f.write('Installation completed\n')
            
            pygame.display.update()
            time.sleep(1)
            
            pygame.quit()
            os.system('python3 prefabs/disk.py')
            break
            
    pygame.display.update()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

pygame.quit()