import time
import threading

class Process:
    def __init__(self, pid, name, target, args=()):
        self.pid = pid
        self.name = name
        self.target = target
        self.args = args
        self.thread = threading.Thread(target=self.run)
        self.alive = False

    def run(self):
        self.alive = True
        self.target(*self.args)
        self.alive = False

    def start(self):
        print(f"Starting process {self.name} (PID: {self.pid})")
        self.thread.start()

    def terminate(self):
        print(f"Terminating process {self.name} (PID: {self.pid})")
        self.alive = False

class Kernel:
    def __init__(self):
        self.process_table = {}
        self.next_pid = 1

    def create_process(self, name, target, args=()):
        pid = self.next_pid
        self.next_pid += 1
        process = Process(pid, name, target, args)
        self.process_table[pid] = process
        process.start()
        return pid

    def kill_process(self, pid):
        if pid in self.process_table:
            process = self.process_table[pid]
            process.terminate()
            del self.process_table[pid]

    def schedule(self):
        while True:
            for pid, process in list(self.process_table.items()):
                if not process.alive:
                    print(f"Process {process.name} (PID: {pid}) has finished.")
                    self.kill_process(pid)
            time.sleep(1)

def task_example(duration):
    print(f"Task running for {duration} seconds...")
    time.sleep(duration)
    print("Task finished.")

if __name__ == "__main__":
    kernel = Kernel()
    kernel.create_process("Process 1", task_example, args=(3,))
    kernel.create_process("Process 2", task_example, args=(5,))
    kernel.schedule()